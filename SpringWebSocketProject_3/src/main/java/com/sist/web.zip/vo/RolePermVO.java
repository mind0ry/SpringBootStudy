package com.sist.web.vo;

import lombok.Data;

@Data
public class RolePermVO {
	
	private int id;
	private String role_name,perm_name;
}
